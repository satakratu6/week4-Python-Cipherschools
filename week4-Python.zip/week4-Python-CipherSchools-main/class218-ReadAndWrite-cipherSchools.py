with open("class214-PythonDebugger-cipherSchools.py",'r') as rf:
    with open("class216-WithBlock-CipherSchools.py","w") as wf:
        wf.write(rf.read())