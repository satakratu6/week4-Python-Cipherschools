import os
os.chdir(r'C:\Users\HP\Desktop\week-3 python')
# print(os.listdir())
print(os.walk('C:\Users\HP\Desktop\week-3 python'))